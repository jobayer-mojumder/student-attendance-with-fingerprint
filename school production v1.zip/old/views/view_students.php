view_students
<!--/.span3-->
<div class="span9">
    <div class="content">
        <?php
        include "views/table.php";
        ?>

    </div>
    <!--/.content-->
</div>

<!--/.span9-->