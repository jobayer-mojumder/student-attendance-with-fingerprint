<div class="module">
    <div class="module-head">
        <h3>
            DataTables</h3>
    </div>
    <div class="module-body table">
        <table cellpadding="0" cellspacing="0" border="0"
               class="datatable-1 table table-bordered table-striped	 display"
               width="100%">
            <thead>
            <tr>
                <th>
                    Rendering engine
                </th>
                <th>
                    Browser
                </th>
                <th>
                    Platform(s)
                </th>
                <th>
                    Engine version
                </th>
                <th>
                    CSS grade
                </th>
            </tr>
            </thead>
            <tbody>


            <tr class="gradeA">
                <td>
                    Gecko
                </td>
                <td>
                    Epiphany 2.20
                </td>
                <td>
                    Gnome
                </td>
                <td class="center">
                    1.8
                </td>
                <td class="center">
                    A
                </td>
            </tr>

            </tr>
            </tbody>
        </table>
    </div>
</div>


