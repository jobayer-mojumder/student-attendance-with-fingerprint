<!--/.span3-->
<div class="span9">
    <div class="content">
        <?php
        include "views/view_student_table.php";
        ?>

    </div>
    <!--/.content-->
</div>

<!--/.span9-->