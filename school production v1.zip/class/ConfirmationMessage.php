<?php
/**
 * Created by PhpStorm.
 * User: OpenCom
 * Date: 1/21/2017
 * Time: 5:32 PM
 */

class MailSent {

    public function sentMessage($full_name,$phone,$username,$password){
        echo'Message Sented';
    }

} 